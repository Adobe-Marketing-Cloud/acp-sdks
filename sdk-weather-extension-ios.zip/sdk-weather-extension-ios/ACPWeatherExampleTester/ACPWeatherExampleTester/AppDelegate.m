//
//  AppDelegate.m
//  Adobe Cloud Platform -- ACP SDK Extension for iOS
//
//  Copyright 1996-2018 Adobe. All Rights Reserved.
//

#import "AppDelegate.h"
#import "WeatherExtensionInternal.h"
#import <ACPCore_iOS/ACPCore_iOS.h>
#import <ACPIdentity_iOS/ACPIdentity_iOS.h>
#import <ACPSignal_iOS/ACPSignal_iOS.h>
#import <ACPLifecycle_iOS/ACPLifecycle_iOS.h>
#import <ACPAnalytics_iOS/ACPAnalytics_iOS.h>

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    [ACPCore setLogLevel:ACPMobileLogLevelError];
    [ACPCore configureWithAppId:@"staging/launch-ENb44c5c8eb4ac4c5b8c89b6afffc167f7-development"];
    
//    [ACPCore configureWithAppId:@"launch-ENb11d768c63354e25875ff8f0b1e1b72d-development"];
    
    // register our weather extension
    NSError *error = nil;
    if ([ACPCore registerExtension:[WeatherExtensionInternal class] error:&error]) {
        NSLog(@"WeatherExtension was successfully registered!");
    } else {
        NSLog(@"An error occurred while attempting to register WeatherExtension: %@", [error localizedDescription]);
    }
    
    [ACPIdentity registerExtension];
    [ACPSignal registerExtension];
    [ACPLifecycle registerExtension];
    [ACPAnalytics registerExtension];
    
    [ACPCore start:^{
        dispatch_async(dispatch_get_main_queue(), ^{
            if ([[UIApplication sharedApplication] applicationState] != UIApplicationStateBackground) {
//                [ACPCore updateConfiguration:@{@"weather.apiKey":@"9d01e08d98d7348712193273da6b89a4"}];
                [ACPCore lifecycleStart:nil];
            }
        });
    }];
    
    return YES;
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    [ACPCore lifecyclePause];
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    [ACPCore lifecycleStart:nil];
}

@end
