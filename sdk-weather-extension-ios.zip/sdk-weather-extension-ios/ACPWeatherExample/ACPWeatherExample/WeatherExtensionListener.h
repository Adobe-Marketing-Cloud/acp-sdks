//
//  WeatherExtensionListener.h
//  Adobe Cloud Platform -- ACP SDK Extension for iOS
//
//  Copyright 1996-2018 Adobe. All Rights Reserved.
//

#import <ACPCore_iOS/ACPCore_iOS.h>

NS_ASSUME_NONNULL_BEGIN

@interface WeatherExtensionListener : ACPExtensionListener

- (void) hear:(ACPExtensionEvent *)event;

@end

NS_ASSUME_NONNULL_END
