# sdk-weather-extension-ios
Sample SDK extension for iOS that demonstrates using weather APIs in the SDK ecosystem
